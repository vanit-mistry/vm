package com.guess.word;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuessWordApplicationTests {

	@Test
	void contextLoads() {
	}
	
	//TODO - rewrite loop, for user to leave loop
//	@Test
//	void main() {
//		GuessWordApplication.main(new String[]{});
//	}

}
